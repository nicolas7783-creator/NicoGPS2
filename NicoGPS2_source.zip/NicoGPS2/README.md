# NicoGPS 3.0

Navigation GPS native Android, avec interface inspirée des GPS modernes.

- Carte OpenStreetMap via osmdroid
- Position GPS et vitesse
- Recherche de destination
- Routage OSRM sans clé OpenRouteService
- Tracé de l'itinéraire
- Carte plein écran + panneau de guidage
- Temps et distance
- Guidage vocal de base
- Recentrage GPS

Cette version est une base de prototype. Les prochaines étapes sont le guidage virage par virage, le recalcul automatique, les alertes et les limitations de vitesse.
