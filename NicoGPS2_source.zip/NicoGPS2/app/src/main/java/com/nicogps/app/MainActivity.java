package com.nicogps.app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.google.android.gms.location.*;
import com.google.gson.*;
import okhttp3.*;
import org.osmdroid.config.Configuration;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.Polyline;
import java.io.IOException;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    private MapView map; private Marker me, dest; private Polyline routeLine; private FusedLocationProviderClient fused;
    private Location current; private TextView status; private EditText destination; private String orsKey=""; private TextToSpeech tts;
    private final ActivityResultLauncher<String[]> perms=registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), r->startGps());

    @Override public void onCreate(Bundle b){ super.onCreate(b); Configuration.getInstance().load(this,getSharedPreferences("osm",0)); setContentView(R.layout.activity_main);
        map=findViewById(R.id.map); status=findViewById(R.id.status); destination=findViewById(R.id.destination);
        map.setMultiTouchControls(true); map.getController().setZoom(16.0); map.setBuiltInZoomControls(true); map.setTilesScaledToDpi(true);
        fused=LocationServices.getFusedLocationProviderClient(this); tts=new TextToSpeech(this,s->{});
        findViewById(R.id.center).setOnClickListener(v->{if(current!=null) center(current);});
        findViewById(R.id.search).setOnClickListener(v->searchDestination());
        findViewById(R.id.settings).setOnClickListener(v->settings());
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) perms.launch(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION}); else startGps();
    }
    private void startGps(){ if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) return;
        LocationRequest req=new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,1000).setMinUpdateIntervalMillis(500).setWaitForAccurateLocation(false).build();
        fused.requestLocationUpdates(req, new LocationCallback(){@Override public void onLocationResult(LocationResult r){ if(r.getLastLocation()!=null) update(r.getLastLocation());}}, getMainLooper());
        fused.getLastLocation().addOnSuccessListener(l->{if(l!=null) update(l);});
    }
    private void update(Location l){ current=l; if(me==null){me=new Marker(map); me.setTitle("Ma position"); me.setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_BOTTOM); map.getOverlays().add(me);} me.setPosition(new GeoPoint(l.getLatitude(),l.getLongitude()));
        map.getController().animateTo(new GeoPoint(l.getLatitude(),l.getLongitude()));
        float speed=l.hasSpeed()?l.getSpeed()*3.6f:0; float acc=l.hasAccuracy()?l.getAccuracy():-1; float bearing=l.hasBearing()?l.getBearing():-1;
        status.setText(String.format(Locale.FRANCE,"%.0f km/h  •  précision %.0f m%s",speed,acc,bearing>=0?String.format(Locale.FRANCE,"  •  cap %.0f°",bearing):"")); map.invalidate();
    }
    private void center(Location l){map.getController().animateTo(new GeoPoint(l.getLatitude(),l.getLongitude())); map.getController().setZoom(17.0);}
    private void searchDestination(){String q=destination.getText().toString().trim(); if(q.isEmpty()||current==null)return; ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(destination.getWindowToken(),0);
        new Thread(()->{try{Geocoder g=new Geocoder(this,Locale.FRANCE); List<Address> a=g.getFromLocationName(q,1); if(a!=null&&!a.isEmpty()){Address x=a.get(0); runOnUiThread(()->setDestination(x.getLatitude(),x.getLongitude(),x.getAddressLine(0)));}else runOnUiThread(()->Toast.makeText(this,"Destination introuvable",Toast.LENGTH_SHORT).show());}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Recherche impossible",Toast.LENGTH_SHORT).show());}}).start();}
    private void setDestination(double lat,double lon,String title){ if(dest==null){dest=new Marker(map); dest.setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_BOTTOM); map.getOverlays().add(dest);} dest.setPosition(new GeoPoint(lat,lon)); dest.setTitle(title); map.getController().animateTo(new GeoPoint(lat,lon)); map.invalidate(); if(orsKey.isEmpty()){Toast.makeText(this,"Destination placée. Ajoute une clé OpenRouteService pour tracer l'itinéraire.",Toast.LENGTH_LONG).show();return;} requestRoute(lat,lon); }
    private void requestRoute(double lat,double lon){if(current==null)return; new Thread(()->{try{String url="https://api.openrouteservice.org/v2/directions/driving-car/geojson"; JsonObject body=new JsonObject(); JsonArray coords=new JsonArray(); JsonArray p1=new JsonArray();p1.add(current.getLongitude());p1.add(current.getLatitude());JsonArray p2=new JsonArray();p2.add(lon);p2.add(lat);coords.add(p1);coords.add(p2);body.add("coordinates",coords); Request req=new Request.Builder().url(url).addHeader("Authorization",orsKey).post(RequestBody.create(body.toString(),MediaType.parse("application/json"))).build(); Response res=new OkHttpClient().newCall(req).execute(); if(!res.isSuccessful())throw new IOException("HTTP "+res.code()); JsonObject root=JsonParser.parseString(res.body().string()).getAsJsonObject(); JsonArray geom=root.getAsJsonArray("features").get(0).getAsJsonObject().getAsJsonObject("geometry").getAsJsonArray("coordinates"); ArrayList<GeoPoint> pts=new ArrayList<>(); for(JsonElement e:geom){JsonArray p=e.getAsJsonArray();pts.add(new GeoPoint(p.get(1).getAsDouble(),p.get(0).getAsDouble()));} runOnUiThread(()->drawRoute(pts)); }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Itinéraire indisponible: "+e.getMessage(),Toast.LENGTH_LONG).show());}}).start();}
    private void drawRoute(ArrayList<GeoPoint> pts){if(routeLine!=null)map.getOverlays().remove(routeLine); routeLine=new Polyline();routeLine.setPoints(pts);routeLine.setWidth(12f);map.getOverlays().add(routeLine);map.invalidate(); speak("Itinéraire calculé");}
    private void speak(String s){if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"nicogps");}
    private void settings(){ final EditText e=new EditText(this);e.setHint("Clé OpenRouteService (optionnelle)");e.setText(orsKey); new AlertDialog.Builder(this).setTitle("Nico GPS — Réglages").setMessage("La clé ORS sert à calculer les itinéraires routiers.").setView(e).setPositiveButton("Enregistrer",(d,w)->{orsKey=e.getText().toString().trim();}).setNegativeButton("Annuler",null).show(); }
    @Override protected void onDestroy(){super.onDestroy(); if(tts!=null){tts.stop();tts.shutdown();} fused.removeLocationUpdates(new LocationCallback(){});}
}
