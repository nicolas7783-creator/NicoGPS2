# Nico GPS 2.0

Projet Android indépendant d'App Inventor.

Fonctions déjà prévues :
- localisation GPS haute précision et mises à jour rapides ;
- carte OpenStreetMap ;
- vitesse en km/h, précision et cap ;
- recherche d'une destination ;
- placement de la destination ;
- calcul d'itinéraire via OpenRouteService si une clé API est fournie ;
- guidage vocal de base via Text-to-Speech ;
- bouton recentrage.

## Compilation
Le workflow `.github/workflows/build.yml` construit automatiquement l'APK debug sur GitHub Actions.

## Clé OpenRouteService
Dans l'application : ⚙ → entrer la clé ORS. La clé n'est pas intégrée au code source.

## Suite prévue
1. guidage vocal tour par tour ;
2. vitesse limite et alertes ;
3. recalcul automatique si sortie de route ;
4. panneaux et indications visuelles ;
5. vue inclinée/navigation avancée.


## Routage
La version 2.1 utilise OSRM pour calculer les itinéraires routiers sans clé API. La réponse GeoJSON est tracée directement sur la carte. Documentation : https://project-osrm.org/docs/
